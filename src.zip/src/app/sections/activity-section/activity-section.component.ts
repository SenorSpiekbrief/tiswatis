import { Component } from '@angular/core';

@Component({
  selector: 'app-activity-section',
  standalone: true,
  imports: [],
  templateUrl: './activity-section.component.html',
  styleUrl: './activity-section.component.scss'
})
export class ActivitySectionComponent {

}
