import { Component } from '@angular/core';

@Component({
  selector: 'app-omgeving-section',
  standalone: true,
  imports: [],
  templateUrl: './omgeving-section.component.html',
  styleUrl: './omgeving-section.component.scss'
})
export class OmgevingSectionComponent {

}
