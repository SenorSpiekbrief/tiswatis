import { Component } from '@angular/core';

@Component({
  selector: 'app-tarieven-section',
  standalone: true,
  imports: [],
  templateUrl: './tarieven-section.component.html',
  styleUrl: './tarieven-section.component.scss'
})
export class TarievenSectionComponent {

}
