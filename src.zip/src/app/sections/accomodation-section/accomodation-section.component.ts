import { Component } from '@angular/core';

@Component({
  selector: 'app-accomodation-section',
  standalone: true,
  imports: [],
  templateUrl: './accomodation-section.component.html',
  styleUrl: './accomodation-section.component.scss'
})
export class AccomodationSectionComponent {

}
